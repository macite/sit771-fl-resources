using System;
using SplashKitSDK;

public class Program
{
  public static void Main()
  {
    Window w = new Window("My Tank", 600, 300);
    StorageTank tnk = new StorageTank();

    w.Clear(Color.White);
    tnk.Draw();
    w.Refresh();

    SplashKit.Delay(5000);
  }
}

public class StorageTank
{
  public void Draw()
  {
    double capacity, level;
    int x, y, width, height;

    x = 10;
    y = 30;
    width = 100;
    height = 200;
    capacity = 1000;
    level = 270;

    double percentFull = level / (double)capacity;
    double waterHeight = height * percentFull;

    SplashKit.FillRectangle(Color.White, x, y, width, height);
    SplashKit.FillRectangle(Color.Blue, x, y, width, waterHeight);
    SplashKit.DrawRectangle(Color.Black, x, y, width, height);
  }
}