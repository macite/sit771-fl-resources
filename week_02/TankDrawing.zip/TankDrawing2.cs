using System;
using SplashKitSDK;

namespace tank2
{
  public class Program
  {
    public static void Main()
    {
      Window w = new Window("My Tank", 600, 600);
      StorageTank tnk = new StorageTank();

      tnk.X = 10;
      tnk.Y = 30;
      tnk.Width = 100;
      tnk.Height = 200;
      tnk.Capacity = 1000;
      tnk.Level = 270;

      w.Clear(Color.White);
      tnk.Draw();
      w.Refresh();

      SplashKit.Delay(1000);
    }
  }

  public class StorageTank
  {
    private double _capacity;
    private double _level;

    private int _x, _y;
    private int _width, _height;

    public double Capacity
    {
      set { _capacity = value; }
      get { return _capacity; }
    }

    public double Level
    {
      set { _level = value; }
      get { return _level; }
    }

    public double PercentFull
    {
      get { return _level / (double)_capacity; }
    }

    public int X
    {
      set { _x = value; }
      get { return _x; }
    }

    public int Y
    {
      set { _y = value; }
      get { return _y; }
    }

    public int Width
    {
      set { _width = value; }
      get { return _width; }
    }

    public int Height
    {
      set { _height = value; }
      get { return _height; }
    }

    public void Draw()
    {
      double waterHeight = _height * PercentFull;
      double topY = _y + _height - waterHeight;

      SplashKit.FillRectangle(Color.White, _x, _y, _width, _height);
      SplashKit.FillRectangle(Color.Blue, _x, topY, _width, waterHeight);
      SplashKit.DrawRectangle(Color.Black, _x, _y, _width, _height);
    }
  }
}