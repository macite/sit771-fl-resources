using System;
using SplashKitSDK;

namespace tank4
{
  public class Program
  {
    public static void Main()
    {
      Window w = new Window("My Tank", 600, 600);
      StorageTank tnk = new StorageTank(10, 30, 100, 200, 1000, 270);
      StorageTank tnk2 = new StorageTank(300, 30, 200, 200, 900, 270);

      w.Clear(Color.White);
      tnk.Draw();
      tnk2.Draw();
      w.Refresh();

      SplashKit.Delay(1000);
    }
  }

  public class StorageTank
  {
    private Color _liquidColor = Color.Blue;
    private readonly double _capacity;
    private double _level;

    private int _x, _y;
    private int _width, _height;

    public StorageTank(int x, int y, int width, int height, double capacity, double startLevel)
    {
      _x = x;
      _y = y;
      _width = width;
      _height = height;

      _capacity = capacity;
      _level = startLevel;
    }

    public double Capacity
    {
      get { return _capacity; }
    }

    public double Level
    {
      set { _level = value; }
      get { return _level; }
    }

    public double PercentFull
    {
      get { return _level / (double)_capacity; }
    }

    public int X
    {
      set { _x = value; }
      get { return _x; }
    }

    public int Y
    {
      set { _y = value; }
      get { return _y; }
    }

    public int Width
    {
      set { _width = value; }
      get { return _width; }
    }

    public int Height
    {
      set { _height = value; }
      get { return _height; }
    }

    public void Draw()
    {
      double waterHeight = _height * PercentFull;
      double topY = _y + _height - waterHeight;

      SplashKit.FillRectangle(Color.White, _x, _y, _width, _height);
      SplashKit.FillRectangle(Color.Blue, _x, topY, _width, waterHeight);
      SplashKit.DrawRectangle(Color.Black, _x, _y, _width, _height);
    }
  }
}
