# Install NPM packages

1. cd to the directory you have cloned
1. execute `npm install` to install all dependencies for the project.

# Running the server

`node .`

# Visit the site

In your browser, visit `localhost:3000`