using SplashKitSDK;

namespace CharacterDrawing1
{

    public class Program
    {
        public static void Main()
        {
            LightSimulator simulation = new LightSimulator();
            simulation.Run();
        }
    }

    public class LightSimulator
    {
        private Window _simWindow;
        private LightBulb _light0;
        private LightBulb _light1;
        private LightBulb _light2;
        private LightSwitch _lightSwitch;
        private LightSwitch _lightSwitch2;

        public LightSimulator()
        {
            _light0 = new LightBulb(10, 10);
            _light1 = new LightBulb(200, 10);
            _light2 = new LightBulb(400, 10);

             _lightSwitch = new LightSwitch { ConnectedLight = _light0, X = 215, Y = 400 };
             _lightSwitch2 = new LightSwitch { ConnectedLight = _light0, X = 400, Y = 400 };
        }

        public void Draw()
        {
            _simWindow.Clear(Color.White);
            _light0.Draw();
            _light1.Draw();
            _light2.Draw();
            _lightSwitch.Draw();
            _lightSwitch2.Draw();
            _simWindow.Refresh(60);
        }
        public void HandleInput()
        {
            SplashKit.ProcessEvents();
            if (_lightSwitch.IsUnderMouse && SplashKit.MouseClicked(MouseButton.LeftButton))
            {
                _lightSwitch.Switch();
            }
            if (_lightSwitch2.IsUnderMouse && SplashKit.MouseClicked(MouseButton.LeftButton))
            {
                _lightSwitch2.Switch();
            }
            if (_light0.IsUnderMouse && SplashKit.MouseClicked(MouseButton.LeftButton))
            {
                if (SplashKit.KeyDown(KeyCode.LeftShiftKey)) _lightSwitch2.ConnectedLight = _light0;
                else _lightSwitch.ConnectedLight = _light0;
            }
            if (_light1.IsUnderMouse && SplashKit.MouseClicked(MouseButton.LeftButton))
            {
                if (SplashKit.KeyDown(KeyCode.LeftShiftKey)) _lightSwitch2.ConnectedLight = _light1;
                else _lightSwitch.ConnectedLight = _light1;
            }
            if (_light2.IsUnderMouse && SplashKit.MouseClicked(MouseButton.LeftButton))
            {
               if (SplashKit.KeyDown(KeyCode.LeftShiftKey)) _lightSwitch2.ConnectedLight = _light2;
                else _lightSwitch.ConnectedLight = _light2;
            }
        }

        public void Run()
        {
            _simWindow = new Window("My Lightroom", 600, 600);
            LoadResources();

            while (!_simWindow.CloseRequested)
            {
                Draw();
                HandleInput();
            }

            _simWindow.Close();
        }

        private void LoadResources()
        {
            SplashKit.LoadBitmap("On", "medium-on-light.png");
            SplashKit.LoadBitmap("Off", "medium-off-light.png");
            SplashKit.LoadBitmap("OnSwitch", "switch-on.jpg");
            SplashKit.LoadBitmap("OffSwitch", "switch-off.jpg");
        }
    }

    public class LightBulb
    {
        private double _x, _y;
        private bool _power;

        public LightBulb(double x, double y)
        {
            _x = x;
            _y = y;
            _power = false;
        }

        public bool Power
        {
            get { return _power; }
        }

        public void TogglePower()
        {
            _power = !_power;
        }

        public Bitmap Image
        {
            get
            {
                if (_power)
                {
                    return SplashKit.BitmapNamed("On");
                }
                else
                {
                    return SplashKit.BitmapNamed("Off");
                }
                //  return SplashKit.BitmapNamed(_power ? "On" : "Off");
            }
        }

        public double X
        {
            set { _x = value; }
            get { return _x; }
        }

        public double Y
        {
            set { _y = value; }
            get { return _y; }
        }

        public double Width
        {
            get { return Image.Width; }
        }

        public double Height
        {
            get { return Image.Height; }
        }

        public bool IsUnderMouse
        {
            get { return Image.PointCollision(_x, _y, SplashKit.MouseX(), SplashKit.MouseY()); }
        }

        public void Draw()
        {
            Image.Draw(_x, _y);
        }
    }

    public class LightSwitch
    {
        private LightBulb _connectedLight;
        private double _x, _y;
        private bool _isOn;

        public LightSwitch()
        {
            _isOn = false;
        }

        public double Width
        {
            get { return Image.Width; }
        }

        public Bitmap Image
        {
            get
            {
                if (_isOn)
                {
                    return SplashKit.BitmapNamed("OnSwitch");
                }
                else
                {
                    return SplashKit.BitmapNamed("OffSwitch");
                }
            }
        }

        public double X
        {
            set { _x = value; }
            get { return _x; }
        }

        public double Y
        {
            set { _y = value; }
            get { return _y; }
        }

        public double Height
        {
            get { return Image.Height; }
        }

        public LightBulb ConnectedLight
        {
            set { _connectedLight = value; }
            get { return _connectedLight; }
        }

        public void Switch()
        {
           _connectedLight.TogglePower();
           _isOn = !_isOn;
        }

        public bool IsUnderMouse
        {
            get { return Image.PointCollision(_x, _y, SplashKit.MouseX(), SplashKit.MouseY()); }
        }

        public void Draw()
        {
            SplashKit.DrawBitmap(Image, _x, _y);
            SplashKit.DrawLine(Color.LimeGreen, _x + Width/2, _y, _connectedLight.X + _connectedLight.Width/2, _connectedLight.Y + _connectedLight.Height);
        }
    }
}
