You can place sound effects in this folder. SplashKit can play ogg, wav, mod, flac, and mp3
