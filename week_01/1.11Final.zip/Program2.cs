using System;
using SplashKitSDK;

public class Program
{
    public static void Main()
    {
        new Window("Hello World", 800, 600);
        new Window("Another Window", 300, 300);
        new Bitmap("Pegasi", "PEgasi.png");
        new SoundEffect("Knock", "Knocking-84643603.wav");
        SplashKit.Delay(5000);
    }
}
