using System;
using SplashKitSDK;

public class Program
{
    public static void Main(string[] args)
    {
        // new Window("Hello World", 800, 600);
        // new Window("Another Window", 300, 300);
        // new Bitmap("Pegasi", "PEgasi.png");
        // new SoundEffect("Knock", "Knocking-84643603.wav");
        // SplashKit.Delay(5000);

        Window helloWindow = new Window("Hello World", 800, 600);
        Window anotherWindow = new Window("Another Window", 300, 300);

        helloWindow.MoveTo(0, 0);
        
        anotherWindow.Clear(Color.Green);
        anotherWindow.Refresh(60);

        Bitmap pegasi =  new Bitmap("Pegasi", "Pegasi.png");        

        helloWindow.Draw(pegasi, 10, 50);
        anotherWindow.Draw(pegasi, 50, 10);

        helloWindow.Refresh(60);
        anotherWindow.Refresh(60);
        
        SoundEffect knock = new SoundEffect("Knock", "Knocking-84643603.wav");
        knock.Play();

        SplashKit.Delay(5000);
    }
}
